from django.contrib import admin
from .models import History

admin.site.register(History)